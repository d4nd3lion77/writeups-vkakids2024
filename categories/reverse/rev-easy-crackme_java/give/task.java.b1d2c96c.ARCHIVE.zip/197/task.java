import java.util.*;

class Check {
    public static void main(String args[]) {
        Check Check = new Check();
        Scanner scanner = new Scanner(System.in); 
        System.out.print("Enter check password: ");
        String userInput = scanner.next();
        if (userInput.startsWith("vka{") && userInput.endsWith("}")) {
            String input = userInput.substring("vka{".length(), userInput.length() - 1);
            if (Check.checkPassword(input)) {
                System.out.println("Good job!!!");
            } else {
                System.out.println("Try harder");
            }
        } else {
            System.out.println("Nope :(");
        }
    }
    public boolean checkPassword(String password) { 
        boolean part1 = password.startsWith("J4v4_codE_");
        boolean part3 = password.endsWith("5Y_tO_READ");
        boolean part2 = password.contains("1s_that_EA");        
        return part1 && part3 && part2;
    }
}
