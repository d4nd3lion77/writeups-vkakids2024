import java.util.*;

class Check {
    public static void main(String args[]) {
        Check Check = new Check();
        Scanner scanner = new Scanner(System.in); 
        System.out.print("Enter check password: ");
        String userInput = scanner.next();
        if (userInput.startsWith("vka{") && userInput.endsWith("}")) {
            String input = userInput.substring("vka{".length(), userInput.length() - 1);
            if (Check.checkPassword(input)) {
                System.out.println("Good job!!!");
            } else {
                System.out.println("Try harder");
            }
        } else {
            System.out.println("Nope :(");
        }
    }
    public boolean checkPassword(String password) { 
        boolean part1 = password.startsWith("j4V4_Cod3_");
        boolean part3 = password.endsWith("sy_t0_RE4D");
        boolean part2 = password.contains("1s_th4T_E4");        
        return part1 && part3 && part2;
    }
}
